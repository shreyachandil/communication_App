document.addEventListener("DOMContentLoaded", function (event) {    

    let loggedUser = JSON.parse(localStorage.getItem("loggedInUser"));
    
    if (loggedUser) {
        
        let logoutBtn = document.getElementById("logout-btn");
        if (logoutBtn) {
            logoutBtn.addEventListener("click", function () {
                localStorage.removeItem("loggedInUser");
                location.href = "./Welcome.html";
                logoutBtn.innerHTML = "Logout";
            });

        }
    } else {
        let logoutBtn = document.getElementById("logout-btn");
        if (logoutBtn) {
            document.getElementById("logout-btn").innerHTML = "Login";
            document.getElementById("logout-btn").addEventListener("click", function () {
                location.href = "./Login.html";
            })
        }

    }

});


const allowOnlyLoggedInUsers = () => {
    var loggedUser = JSON.parse(localStorage.getItem("loggedInUser"));
    if (!loggedUser) {
        location.href = "./Welcome.html";
    }
}

